<?php
include_once 'functions.php';

include_once 'layout/header.php';

?>



<?php
include_once 'layout/footer.php';
?>
<?php
header("Location: ".SITE_URL);
exit();
?>
